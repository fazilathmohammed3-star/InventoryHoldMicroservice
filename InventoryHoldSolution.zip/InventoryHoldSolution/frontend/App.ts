import { useEffect, useState } from "react";

function App() {
  const [inventory, setInventory] = useState<any[]>([]);

  useEffect(() => {
    fetch("/api/inventory")
      .then(res => res.json())
      .then(setInventory);
  }, []);

  return (
    <div>
      <h1>Inventory</h1>
      {inventory.map(i => (
        <div key={i.id}>
          {i.productName} - {i.availableQuantity}
        </div>
      ))}
    </div>
  );
}

export default App;