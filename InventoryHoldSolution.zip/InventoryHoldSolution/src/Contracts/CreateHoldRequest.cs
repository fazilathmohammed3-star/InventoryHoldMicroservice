public class CreateHoldRequest
{
    public List<HoldItemDto> Items { get; set; }
}

public class HoldItemDto
{
    public string ProductId { get; set; }
    public int Quantity { get; set; }
}