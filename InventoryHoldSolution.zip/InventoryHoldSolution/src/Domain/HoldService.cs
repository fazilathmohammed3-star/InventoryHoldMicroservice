public class HoldService
{
    private readonly IInventoryRepository _inventory;
    private readonly IHoldRepository _holds;
    private readonly ICacheService _cache;
    private readonly IMessagePublisher _publisher;

    public HoldService(IInventoryRepository inventory,
                       IHoldRepository holds,
                       ICacheService cache,
                       IMessagePublisher publisher)
    {
        _inventory = inventory;
        _holds = holds;
        _cache = cache;
        _publisher = publisher;
    }

    public async Task<Hold> CreateHold(CreateHoldRequest request)
    {
        foreach (var item in request.Items)
        {
            var ok = await _inventory.TryReserveStock(item.ProductId, item.Quantity);
            if (!ok)
                throw new Exception($"Insufficient stock for {item.ProductId}");
        }

        var hold = new Hold
        {
            Items = request.Items,
            ExpiresAt = DateTime.UtcNow.AddMinutes(15)
        };

        await _holds.Create(hold);

        await _publisher.Publish("HoldCreated", hold);

        await _cache.Remove("inventory");

        return hold;
    }

    public async Task<Hold> Get(string id)
    {
        var hold = await _holds.Get(id);
        if (hold == null) return null;

        if (hold.ExpiresAt < DateTime.UtcNow && hold.Status == "ACTIVE")
        {
            hold.Status = "EXPIRED";

            foreach (var item in hold.Items)
                await _inventory.RestoreStock(item.ProductId, item.Quantity);

            await _holds.Update(hold);
            await _publisher.Publish("HoldExpired", hold);
        }

        return hold;
    }

    public async Task<bool> Release(string id)
    {
        var hold = await _holds.Get(id);
        if (hold == null || hold.Status != "ACTIVE")
            return false;

        foreach (var item in hold.Items)
            await _inventory.RestoreStock(item.ProductId, item.Quantity);

        hold.Status = "RELEASED";
        await _holds.Update(hold);

        await _publisher.Publish("HoldReleased", hold);
        await _cache.Remove("inventory");

        return true;
    }
}