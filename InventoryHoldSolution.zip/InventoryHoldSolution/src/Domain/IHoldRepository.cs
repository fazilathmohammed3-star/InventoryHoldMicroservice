public interface IHoldRepository
{
    Task Create(Hold hold);
    Task<Hold> Get(string id);
    Task Update(Hold hold);
}