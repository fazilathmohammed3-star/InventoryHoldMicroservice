public interface IInventoryRepository
{
    Task<bool> TryReserveStock(string productId, int qty);
    Task RestoreStock(string productId, int qty);
    Task<List<InventoryItem>> GetAll();
}
