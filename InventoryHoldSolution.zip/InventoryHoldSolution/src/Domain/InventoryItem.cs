public class InventoryItem
{
    public string Id { get; set; }
    public string ProductName { get; set; }
    public int AvailableQuantity { get; set; }
}

public class Hold
{
    public string Id { get; set; } = Guid.NewGuid().ToString();
    public List<HoldItemDto> Items { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime ExpiresAt { get; set; }
    public string Status { get; set; } = "ACTIVE";
}