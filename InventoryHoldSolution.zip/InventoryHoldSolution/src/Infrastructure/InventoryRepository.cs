public class InventoryRepository : IInventoryRepository
{
    private readonly IMongoCollection<InventoryItem> _collection;

    public InventoryRepository(IMongoDatabase db)
    {
        _collection = db.GetCollection<InventoryItem>("inventory");
    }

    public async Task<bool> TryReserveStock(string productId, int qty)
    {
        var filter = Builders<InventoryItem>.Filter.And(
            Builders<InventoryItem>.Filter.Eq(x => x.Id, productId),
            Builders<InventoryItem>.Filter.Gte(x => x.AvailableQuantity, qty)
        );

        var update = Builders<InventoryItem>.Update.Inc(x => x.AvailableQuantity, -qty);

        var result = await _collection.UpdateOneAsync(filter, update);

        return result.ModifiedCount == 1;
    }

    public async Task RestoreStock(string productId, int qty)
    {
        var update = Builders<InventoryItem>.Update.Inc(x => x.AvailableQuantity, qty);
        await _collection.UpdateOneAsync(x => x.Id == productId, update);
    }

    public async Task<List<InventoryItem>> GetAll()
    {
        return await _collection.Find(_ => true).ToListAsync();
    }
}