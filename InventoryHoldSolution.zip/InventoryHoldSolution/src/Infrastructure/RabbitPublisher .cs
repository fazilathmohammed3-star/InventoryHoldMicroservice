public class RabbitPublisher : IMessagePublisher
{
    private readonly IConnection _connection;

    public RabbitPublisher()
    {
        var factory = new ConnectionFactory() { HostName = "rabbitmq" };
        _connection = factory.CreateConnection();
    }

    public Task Publish(string eventName, object data)
    {
        using var channel = _connection.CreateModel();

        channel.ExchangeDeclare("holds_exchange", ExchangeType.Fanout);

        var body = Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(data));

        channel.BasicPublish("holds_exchange", "", null, body);

        return Task.CompletedTask;
    }
}