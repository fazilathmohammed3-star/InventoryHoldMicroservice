public class RedisCacheService : ICacheService
{
    private readonly IDatabase _db;

    public RedisCacheService(IConnectionMultiplexer redis)
    {
        _db = redis.GetDatabase();
    }

    public async Task<T> Get<T>(string key)
    {
        var value = await _db.StringGetAsync(key);
        return value.IsNull ? default : JsonConvert.DeserializeObject<T>(value);
    }

    public async Task Set<T>(string key, T value, TimeSpan ttl)
    {
        await _db.StringSetAsync(key, JsonConvert.SerializeObject(value), ttl);
    }

    public async Task Remove(string key)
    {
        await _db.KeyDeleteAsync(key);
    }
}