public class HoldServiceTests
{
    [Fact]
    public async Task CreateHold_ShouldSucceed()
    {
        var inv = new Mock<IInventoryRepository>();
        inv.Setup(x => x.TryReserveStock(It.IsAny<string>(), It.IsAny<int>()))
           .ReturnsAsync(true);

        var service = new HoldService(inv.Object,
                                      new Mock<IHoldRepository>().Object,
                                      new Mock<ICacheService>().Object,
                                      new Mock<IMessagePublisher>().Object);

        var result = await service.CreateHold(new CreateHoldRequest
        {
            Items = new List<HoldItemDto> {
                new HoldItemDto { ProductId="1", Quantity=1 }
            }
        });

        Assert.NotNull(result);
    }
}