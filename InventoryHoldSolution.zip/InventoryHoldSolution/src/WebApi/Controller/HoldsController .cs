[ApiController]
[Route("api/holds")]
public class HoldsController : ControllerBase
{
    private readonly HoldService _service;

    public HoldsController(HoldService service)
    {
        _service = service;
    }

    [HttpPost]
    public async Task<IActionResult> Create(CreateHoldRequest req)
    {
        var result = await _service.CreateHold(req);
        return Created("", result);
    }

    [HttpGet("{id}")]
    public async Task<IActionResult> Get(string id)
    {
        var hold = await _service.Get(id);
        if (hold == null) return NotFound();
        return Ok(hold);
    }

    [HttpDelete("{id}")]
    public async Task<IActionResult> Delete(string id)
    {
        var ok = await _service.Release(id);
        if (!ok) return NotFound();
        return Ok();
    }
}